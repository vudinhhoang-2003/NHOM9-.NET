﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyDanhBa
{
    public partial class suaNguoiDung : Form
    {
        private string connectionString = @"Data Source=VUHOANG\SQLEXPRESS;Initial Catalog=quanLyDanhBa;Integrated Security=True;Encrypt=False;";
        private string hoTen;

        public suaNguoiDung(string hoTen)
        {
            InitializeComponent();
            this.hoTen = hoTen;
        }

        private void suaNguoiDung_Load(object sender, EventArgs e)
        {
            LoadUserData();
        }

        private void LoadUserData()
        {
            string query = "SELECT * FROM tblNguoi WHERE hoTen = @hoTen";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@hoTen", hoTen);
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    txtName.Text = reader["hoTen"].ToString();
                    txtSDT.Text = reader["soDienThoai"].ToString();
                    txtDiaChi.Text = reader["diaChi"].ToString();
                    txtGhiChu.Text = reader["ghiChu"].ToString();
                    txtCQ.Text = GetTenCoQuan(reader["idCoQuan"].ToString());
                    txtQH.Text = GetTenQH(reader["idQH"].ToString());
                    txtTP.Text = GetTenTP(reader["idTP"].ToString());
                }
            }
        }

        private string GetTenCoQuan(string idCoQuan)
        {
            string query = "SELECT tenCoQuan FROM tblCoQuan WHERE idCoQuan = @idCoQuan";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@idCoQuan", idCoQuan);
                connection.Open();
                return command.ExecuteScalar().ToString();
            }
        }

        private string GetTenQH(string idQH)
        {
            string query = "SELECT tenQH FROM tblQuanHuyen WHERE idQH = @idQH";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@idQH", idQH);
                connection.Open();
                return command.ExecuteScalar().ToString();
            }
        }

        private string GetTenTP(string idTP)
        {
            string query = "SELECT tenTP FROM tblThanhPho WHERE idTP = @idTP";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@idTP", idTP);
                connection.Open();
                return command.ExecuteScalar().ToString();
            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            UpdateUserData();
        }

        private void UpdateUserData()
        {
            string name = txtName.Text.Trim();
            string phone = txtSDT.Text.Trim();
            string diaChi = txtDiaChi.Text.Trim();
            string ghiChu = txtGhiChu.Text.Trim();
            string coQuan = txtCQ.Text.Trim();
            string quanHuyen = txtQH.Text.Trim();
            string thanhPho = txtTP.Text.Trim();

            string idCoQuan = GetId(connectionString, "tblCoQuan", "tenCoQuan", coQuan, "idCoQuan");
            string idQH = GetId(connectionString, "tblQuanHuyen", "tenQH", quanHuyen, "idQH");
            string idTP = GetId(connectionString, "tblThanhPho", "tenTP", thanhPho, "idTP");

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(diaChi))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string queryUpdate = "UPDATE tblNguoi SET hoTen = @hoTen, soDienThoai = @soDienThoai, diaChi = @diaChi, ghiChu = @ghiChu, idCoQuan = @idCoQuan, idQH = @idQH, idTP = @idTP WHERE hoTen = @hoTenOld";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(queryUpdate, connection))
                {
                    command.Parameters.AddWithValue("@hoTen", name);
                    command.Parameters.AddWithValue("@soDienThoai", phone);
                    command.Parameters.AddWithValue("@diaChi", diaChi);
                    command.Parameters.AddWithValue("@ghiChu", ghiChu);
                    command.Parameters.AddWithValue("@idCoQuan", idCoQuan);
                    command.Parameters.AddWithValue("@idQH", idQH);
                    command.Parameters.AddWithValue("@idTP", idTP);
                    command.Parameters.AddWithValue("@hoTenOld", hoTen);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Dữ liệu đã được cập nhật thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private string GetId(string connectionString, string tableName, string columnName, string value, string idColumnName)
        {
            string query = $"SELECT {idColumnName} FROM {tableName} WHERE {columnName} = @value";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@value", value);
                connection.Open();
                return command.ExecuteScalar().ToString();
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnThemCQ_Click(object sender, EventArgs e)
        {
            themCoQuan themCoQuanForm = new themCoQuan();
            themCoQuanForm.Show();
        }

        private void btnThemQH_Click(object sender, EventArgs e)
        {
            themDiachi themDiaChiForm = new themDiachi();
            themDiaChiForm.Show();
        }

        private void btnThemTP_Click(object sender, EventArgs e)
        {
            themThanhPho themTPForm = new themThanhPho();
            themTPForm.Show();
        }
    }
}
