﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyDanhBa
{
    public partial class themThanhPho : Form
    {
        private string connectionString = @"Data Source=VUHOANG\SQLEXPRESS;Initial Catalog=quanLyDanhBa;Integrated Security=True;Encrypt=False;"; // Chuỗi kết nối đến cơ sở dữ liệu

        public themThanhPho()
        {
            InitializeComponent();
        }

        private void btnThemAddress_Click(object sender, EventArgs e)
        {
            
            string idTP = txtIdTP.Text.Trim();
            string tenTP = txtTenTP.Text.Trim();

            // Kiểm tra xem ô nhập liệu có rỗng hay không
            if (string.IsNullOrEmpty(tenTP))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Kết nối đến cơ sở dữ liệu và thêm dữ liệu vào hai bảng riêng biệt
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Thêm vào bảng tblThanhPho
                    string queryThanhPho = "INSERT INTO tblThanhPho (idTP, tenTP) VALUES (@idTP, @tenTP)";
                    using (SqlCommand commandThanhPho = new SqlCommand(queryThanhPho, connection))
                    {
                        commandThanhPho.Parameters.AddWithValue("@idTP", idTP);
                        commandThanhPho.Parameters.AddWithValue("@tenTP", tenTP);
                        commandThanhPho.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Thêm địa chỉ thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Đóng form hiện tại sau khi thêm thành công
                this.Close();
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Lỗi SQL khi thêm địa chỉ: " + sqlEx.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm địa chỉ: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            // Đóng form hiện tại
            this.Close();
        }

        private void themThanhPho_Load(object sender, EventArgs e)
        {

        }
    }
}
