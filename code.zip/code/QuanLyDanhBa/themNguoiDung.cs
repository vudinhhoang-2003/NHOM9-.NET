﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyDanhBa
{
    public partial class themNguoiDung : Form
    {
        public themNguoiDung()
        {
            InitializeComponent();
        }

        private void themNguoiDung_Load(object sender, EventArgs e)
        {
            // Không cần load dữ liệu vào ComboBox
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            SaveData();
        }

        private void SaveData()
        {
            string connectionString = @"Data Source=VUHOANG\SQLEXPRESS;Initial Catalog=quanLyDanhBa;Integrated Security=True;Encrypt=False;";

            string coQuan = txtCQ.Text.Trim();
            string quanHuyen = txtQH.Text.Trim();
            string thanhPho = txtTP.Text.Trim();
            string soDienThoai = txtSDT.Text.Trim();

            // Check sđt 
            if (CheckIfExists(connectionString, "tblNguoi", "soDienThoai", soDienThoai))
            {
                MessageBox.Show("Số điện thoại đã tồn tại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check co quan
            if (!CheckIfExists(connectionString, "tblCoQuan", "tenCoQuan", coQuan))
            {
                MessageBox.Show("Cơ quan không tồn tại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check quan huyen
            if (!CheckIfExists(connectionString, "tblQuanHuyen", "tenQH", quanHuyen))
            {
                MessageBox.Show("Quận/Huyện không tồn tại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check thanh pho
            if (!CheckIfExists(connectionString, "tblThanhPho", "tenTP", thanhPho))
            {
                MessageBox.Show("Thành phố không tồn tại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string idCoQuan = GetId(connectionString, "tblCoQuan", "tenCoQuan", coQuan, "idCoQuan");
            string idQH = GetId(connectionString, "tblQuanHuyen", "tenQH", quanHuyen, "idQH");
            string idTP = GetId(connectionString, "tblThanhPho", "tenTP", thanhPho, "idTP");

            string queryInsert = "INSERT INTO tblNguoi (hoTen, soDienThoai, idCoQuan, diaChi, idQH, idTP, ghiChu) " +
                                 "VALUES (@hoTen, @soDienThoai, @idCoQuan, @diaChi, @idQH, @idTP, @ghiChu)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(queryInsert, connection))
                {
                    command.Parameters.AddWithValue("@hoTen", txtName.Text.Trim());
                    command.Parameters.AddWithValue("@soDienThoai", soDienThoai);
                    command.Parameters.AddWithValue("@idCoQuan", idCoQuan);
                    command.Parameters.AddWithValue("@diaChi", txtDiaChi.Text.Trim());
                    command.Parameters.AddWithValue("@idQH", idQH);
                    command.Parameters.AddWithValue("@idTP", idTP);
                    command.Parameters.AddWithValue("@ghiChu", txtGhiChu.Text.Trim());

                    command.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Dữ liệu đã được lưu thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private bool CheckIfExists(string connectionString, string tableName, string columnName, string value)
        {
            string query = $"SELECT COUNT(*) FROM {tableName} WHERE {columnName} = @value";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@value", value);
                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }

        private string GetId(string connectionString, string tableName, string columnName, string value, string idColumnName)
        {
            string query = $"SELECT {idColumnName} FROM {tableName} WHERE {columnName} = @value";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@value", value);
                    return (string)command.ExecuteScalar();
                }
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnThemCQ_Click_1(object sender, EventArgs e)
        {
            themCoQuan themCoQuanForm = new themCoQuan();
            themCoQuanForm.Show();
        }

        private void btnThemDiaChi_Click(object sender, EventArgs e)
        {
            themDiachi themDiaChiForm = new themDiachi();
            themDiaChiForm.Show();
        }

        private void btnThemTP_Click(object sender, EventArgs e)
        {
            themThanhPho themTPForm = new themThanhPho();
            themTPForm.Show();
        }

        private void themNguoiDung_Load_1(object sender, EventArgs e)
        {

        }
    }
}
