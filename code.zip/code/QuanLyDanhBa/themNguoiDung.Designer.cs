﻿namespace QuanLyDanhBa
{
    partial class themNguoiDung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.btnThemCQ = new System.Windows.Forms.Button();
            this.btnThemDiaChi = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnThemTP = new System.Windows.Forms.Button();
            this.txtCQ = new System.Windows.Forms.TextBox();
            this.txtQH = new System.Windows.Forms.TextBox();
            this.txtTP = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(100, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Họ và tên";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(100, 187);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Địa chỉ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(100, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Cơ quan";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(100, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Số điện thoại";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(100, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Ghi chú";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(233, 51);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 22);
            this.txtName.TabIndex = 6;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(233, 187);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(100, 22);
            this.txtDiaChi.TabIndex = 7;
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(233, 94);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(100, 22);
            this.txtSDT.TabIndex = 9;
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(233, 240);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(100, 22);
            this.txtGhiChu.TabIndex = 10;
            // 
            // btnThemCQ
            // 
            this.btnThemCQ.Location = new System.Drawing.Point(364, 139);
            this.btnThemCQ.Name = "btnThemCQ";
            this.btnThemCQ.Size = new System.Drawing.Size(118, 23);
            this.btnThemCQ.TabIndex = 12;
            this.btnThemCQ.Text = "Thêm cơ quan";
            this.btnThemCQ.UseVisualStyleBackColor = true;
            this.btnThemCQ.Click += new System.EventHandler(this.btnThemCQ_Click_1);
            // 
            // btnThemDiaChi
            // 
            this.btnThemDiaChi.Location = new System.Drawing.Point(670, 184);
            this.btnThemDiaChi.Name = "btnThemDiaChi";
            this.btnThemDiaChi.Size = new System.Drawing.Size(118, 23);
            this.btnThemDiaChi.TabIndex = 15;
            this.btnThemDiaChi.Text = "Thêm QH";
            this.btnThemDiaChi.UseVisualStyleBackColor = true;
            this.btnThemDiaChi.Click += new System.EventHandler(this.btnThemDiaChi_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.Location = new System.Drawing.Point(349, 333);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(118, 23);
            this.btnLuu.TabIndex = 16;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.Location = new System.Drawing.Point(491, 333);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(118, 23);
            this.btnHuy.TabIndex = 17;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // btnThemTP
            // 
            this.btnThemTP.Location = new System.Drawing.Point(670, 237);
            this.btnThemTP.Name = "btnThemTP";
            this.btnThemTP.Size = new System.Drawing.Size(118, 23);
            this.btnThemTP.TabIndex = 21;
            this.btnThemTP.Text = "Thêm TP";
            this.btnThemTP.UseVisualStyleBackColor = true;
            this.btnThemTP.Click += new System.EventHandler(this.btnThemTP_Click);
            // 
            // txtCQ
            // 
            this.txtCQ.Location = new System.Drawing.Point(233, 140);
            this.txtCQ.Name = "txtCQ";
            this.txtCQ.Size = new System.Drawing.Size(100, 22);
            this.txtCQ.TabIndex = 22;
            // 
            // txtQH
            // 
            this.txtQH.Location = new System.Drawing.Point(364, 187);
            this.txtQH.Name = "txtQH";
            this.txtQH.Size = new System.Drawing.Size(100, 22);
            this.txtQH.TabIndex = 23;
            // 
            // txtTP
            // 
            this.txtTP.Location = new System.Drawing.Point(528, 187);
            this.txtTP.Name = "txtTP";
            this.txtTP.Size = new System.Drawing.Size(100, 22);
            this.txtTP.TabIndex = 24;
            // 
            // themNguoiDung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtTP);
            this.Controls.Add(this.txtQH);
            this.Controls.Add(this.txtCQ);
            this.Controls.Add(this.btnThemTP);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.btnThemDiaChi);
            this.Controls.Add(this.btnThemCQ);
            this.Controls.Add(this.txtGhiChu);
            this.Controls.Add(this.txtSDT);
            this.Controls.Add(this.txtDiaChi);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "themNguoiDung";
            this.Text = "themNguoiDung";
            this.Load += new System.EventHandler(this.themNguoiDung_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.Button btnThemCQ;
        private System.Windows.Forms.Button btnThemDiaChi;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnThemTP;
        private System.Windows.Forms.TextBox txtCQ;
        private System.Windows.Forms.TextBox txtQH;
        private System.Windows.Forms.TextBox txtTP;
    }
}