﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyDanhBa
{
    public partial class Form1 : Form
    {
        int Index = -1; // Chỉ mục của hàng đang được chọn trong DataGridView

        private string connectionString = @"Data Source=VUHOANG\SQLEXPRESS;Initial Catalog=quanLyDanhBa;Integrated Security=True;Encrypt=False;"; // Chuỗi kết nối đến cơ sở dữ liệu
        private DataTable dataTable; // Bảng dữ liệu chứa dữ liệu từ cơ sở dữ liệu

        public Form1()
        {
            InitializeComponent();
        }

        // Phương thức để tải dữ liệu từ cơ sở dữ liệu vào DataGridView
        private void LoadDataFromDatabase()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT (tblNguoi.hoTen) AS 'Họ và tên', (tblNguoi.soDienThoai) AS 'Số điện thoại', (tblCoQuan.tenCoQuan) AS 'Cơ quan', (tblNguoi.diaChi) AS 'Địa chỉ', (tblQuanHuyen.tenQH) AS 'Quận/Huyện', (tblThanhPho.tenTP) AS 'Thành phố', (tblNguoi.ghiChu) AS 'Ghi chú' " +
                                   "FROM tblNguoi " +
                                   "JOIN tblCoQuan ON tblNguoi.idCoQuan = tblCoQuan.idCoQuan " +
                                   "JOIN tblThanhPho ON tblNguoi.idTP = tblThanhPho.idTP " +
                                   "JOIN tblQuanHuyen ON tblNguoi.idQH = tblQuanHuyen.idQH;";
                    using (SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection))
                    {
                        dataTable = new DataTable();
                        dataAdapter.Fill(dataTable);
                        dtgvPhoneBook.DataSource = dataTable; // Gán dữ liệu vào DataGridView
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Lỗi SQL khi tải dữ liệu: " + sqlEx.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu từ cơ sở dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Phương thức để kích hoạt hoặc tắt các điều khiển trên form
        private void EnableControls(bool isEnableTextBox, bool isEnableDataGridView)
        {
            txbName.Enabled  = isEnableTextBox; // Kích hoạt hoặc tắt các ô textbox
            dtgvPhoneBook.Enabled = isEnableDataGridView; // Kích hoạt hoặc tắt DataGridView
        }

        // Phương thức để xóa trắng các ô textbox trên form
        private void ClearTextBoxes()
        {
            txbName.Clear();
        }

        // Sự kiện xảy ra khi form được tải
        private void Form1_Load(object sender, EventArgs e)
        {
            EnableControls(false, true); // Tắt các điều khiển trên form trừ DataGridView
            LoadDataFromDatabase(); // Tải dữ liệu từ cơ sở dữ liệu
            btnHuy.Enabled = false; // Vô hiệu hóa nút Lưu và Hủy
        }

        // Sự kiện xảy ra khi nút Thêm được nhấn
        private void btnAdd_Click(object sender, EventArgs e)
        {
            themNguoiDung themForm = new themNguoiDung(); // Tạo một instance mới của form "Them"
            themForm.Show(); // Hiển thị form "Them" (ứng dụng vẫn có thể tương tác với các form khác)
        }

        // Sự kiện xảy ra khi nút Cập nhật được nhấn
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dtgvPhoneBook.SelectedRows.Count > 0)
            {
                int selectedRowIndex = dtgvPhoneBook.SelectedRows[0].Index;
                string hoTen = dtgvPhoneBook.Rows[selectedRowIndex].Cells["Họ và tên"].Value.ToString();
                suaNguoiDung suaForm = new suaNguoiDung(hoTen);
                suaForm.Show();
            }
            else
            {
                MessageBox.Show("Hãy chọn một bản ghi để sửa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Sự kiện xảy ra khi một ô trong DataGridView được nhấp chuột
        private void dtgvPhoneBook_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Index = e.RowIndex; // Lấy chỉ mục của hàng được chọn
        }

        // Sự kiện xảy ra khi nút Xóa được nhấn
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (Index < 0)
            {
                MessageBox.Show("Hãy chọn một bản ghi", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Lấy thông tin cần thiết từ hàng được chọn
            string name = dtgvPhoneBook.Rows[Index].Cells["Họ và tên"].Value.ToString();
            string phone = dtgvPhoneBook.Rows[Index].Cells["Số điện thoại"].Value.ToString();
            string coQuan = dtgvPhoneBook.Rows[Index].Cells["Cơ quan"].Value.ToString();
            string diaChi = dtgvPhoneBook.Rows[Index].Cells["Địa chỉ"].Value.ToString();
            string quanHuyen = dtgvPhoneBook.Rows[Index].Cells["Quận/Huyện"].Value.ToString();
            string thanhPho = dtgvPhoneBook.Rows[Index].Cells["Thành phố"].Value.ToString();
            string ghiChu = dtgvPhoneBook.Rows[Index].Cells["Ghi chú"].Value.ToString();

            // Xác nhận việc xóa bản ghi
            if (MessageBox.Show("Bạn có chắc chắn muốn xóa bản ghi này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    // Kết nối đến cơ sở dữ liệu và thực hiện xóa bản ghi
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        string query = "DELETE FROM tblNguoi WHERE hoTen = @hoTen AND soDienThoai = @soDienThoai AND diaChi = @diaChi AND " +
                                       "ghiChu = @ghiChu AND idCoQuan = (SELECT idCoQuan FROM tblCoQuan WHERE tenCoQuan = @tenCoQuan) AND " +
                                       "idQH = (SELECT idQH FROM tblQuanHuyen WHERE tenQH = @tenQH) AND idTP = (SELECT idTP FROM tblThanhPho WHERE tenTP = @tenTP)";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@hoTen", name);
                            command.Parameters.AddWithValue("@soDienThoai", phone);
                            command.Parameters.AddWithValue("@diaChi", diaChi);
                            command.Parameters.AddWithValue("@ghiChu", ghiChu);
                            command.Parameters.AddWithValue("@tenCoQuan", coQuan);
                            command.Parameters.AddWithValue("@tenQH", quanHuyen);
                            command.Parameters.AddWithValue("@tenTP", thanhPho);
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Xóa bản ghi thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadDataFromDatabase(); // Tải lại dữ liệu từ cơ sở dữ liệu
                            }
                            else
                            {
                                MessageBox.Show("Không tìm thấy bản ghi để xóa", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    MessageBox.Show("Lỗi SQL khi xóa dữ liệu: " + sqlEx.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi xóa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        // Sự kiện xảy ra khi nút Hủy được nhấn
        private void btnHuy_Click(object sender, EventArgs e)
        {
            ClearTextBoxes(); // Xóa trắng các ô textbox
            EnableControls(false, true); // Tắt các ô textbox và kích hoạt DataGridView
            btnAdd.Enabled = btnUpdate.Enabled = btnDelete.Enabled = true; // Kích hoạt các nút Thêm, Cập nhật và Xóa
            btnHuy.Enabled = false; // Vô hiệu hóa nút Hủy
            LoadDataFromDatabase(); // Tải lại dữ liệu từ cơ sở dữ liệu
        }

        // Sự kiện xảy ra khi mục thoát trong menu được nhấn
        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit(); // Thoát ứng dụng
        }

        // Sự kiện xảy ra khi nút Tìm kiếm được nhấn
        private void btnSearch_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem ô tìm kiếm có rỗng hay không
            if (string.IsNullOrEmpty(txbName.Text.Trim()))
            {
                // Nếu rỗng, cho phép người dùng nhập liệu
                txbName.Enabled = btnHuy.Enabled = true;
                txbName.Focus(); // Di chuyển trỏ chuột vào ô tìm kiếm
                btnAdd.Enabled = false;
            }
            else
            {
                // Nếu không rỗng, thực hiện tìm kiếm
                PerformSearch();
            }
        }

        // Phương thức để thực hiện tìm kiếm
        private void PerformSearch()
        {
            string search = txbName.Text.Trim();

            if (!string.IsNullOrEmpty(search))
            {
                // Tạo một DataView để lọc dữ liệu từ DataTable
                DataView dv = dataTable.DefaultView;
                dv.RowFilter = string.Format("[Họ và tên] LIKE '%{0}%'", search);

                // Hiển thị kết quả tìm kiếm trong DataGridView
                dtgvPhoneBook.DataSource = dv.ToTable();
            }
            else
            {
                // Nếu ô tìm kiếm trống, hiển thị toàn bộ dữ liệu
                dtgvPhoneBook.DataSource = dataTable;
            }
        }

        // Sự kiện xảy ra khi nội dung của ô tìm kiếm thay đổi
        private void txbName_TextChanged(object sender, EventArgs e)
        {
            // Khi nội dung của ô tìm kiếm thay đổi, thực hiện tìm kiếm
            PerformSearch();
        }
    }
}
