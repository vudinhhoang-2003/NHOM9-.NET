﻿namespace QuanLyDanhBa
{
    partial class suaNguoiDung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnThemTP = new System.Windows.Forms.Button();
            this.txtTP = new System.Windows.Forms.TextBox();
            this.txtQH = new System.Windows.Forms.TextBox();
            this.txtCQ = new System.Windows.Forms.TextBox();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnThemQH = new System.Windows.Forms.Button();
            this.btnThemCQ = new System.Windows.Forms.Button();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnThemTP
            // 
            this.btnThemTP.Location = new System.Drawing.Point(604, 258);
            this.btnThemTP.Name = "btnThemTP";
            this.btnThemTP.Size = new System.Drawing.Size(118, 23);
            this.btnThemTP.TabIndex = 54;
            this.btnThemTP.Text = "Thêm TP";
            this.btnThemTP.UseVisualStyleBackColor = true;
            this.btnThemTP.Click += new System.EventHandler(this.btnThemTP_Click);
            // 
            // txtTP
            // 
            this.txtTP.Location = new System.Drawing.Point(470, 210);
            this.txtTP.Name = "txtTP";
            this.txtTP.Size = new System.Drawing.Size(118, 22);
            this.txtTP.TabIndex = 53;
            // 
            // txtQH
            // 
            this.txtQH.Location = new System.Drawing.Point(334, 210);
            this.txtQH.Name = "txtQH";
            this.txtQH.Size = new System.Drawing.Size(112, 22);
            this.txtQH.TabIndex = 52;
            // 
            // txtCQ
            // 
            this.txtCQ.Location = new System.Drawing.Point(212, 162);
            this.txtCQ.Name = "txtCQ";
            this.txtCQ.Size = new System.Drawing.Size(100, 22);
            this.txtCQ.TabIndex = 51;
            // 
            // btnHuy
            // 
            this.btnHuy.Location = new System.Drawing.Point(470, 355);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(118, 23);
            this.btnHuy.TabIndex = 50;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.Location = new System.Drawing.Point(328, 355);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(118, 23);
            this.btnLuu.TabIndex = 49;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnThemQH
            // 
            this.btnThemQH.Location = new System.Drawing.Point(604, 209);
            this.btnThemQH.Name = "btnThemQH";
            this.btnThemQH.Size = new System.Drawing.Size(118, 23);
            this.btnThemQH.TabIndex = 48;
            this.btnThemQH.Text = "Thêm QH";
            this.btnThemQH.UseVisualStyleBackColor = true;
            this.btnThemQH.Click += new System.EventHandler(this.btnThemQH_Click);
            // 
            // btnThemCQ
            // 
            this.btnThemCQ.Location = new System.Drawing.Point(334, 161);
            this.btnThemCQ.Name = "btnThemCQ";
            this.btnThemCQ.Size = new System.Drawing.Size(118, 23);
            this.btnThemCQ.TabIndex = 47;
            this.btnThemCQ.Text = "Thêm cơ quan";
            this.btnThemCQ.UseVisualStyleBackColor = true;
            this.btnThemCQ.Click += new System.EventHandler(this.btnThemCQ_Click);
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(212, 262);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(100, 22);
            this.txtGhiChu.TabIndex = 46;
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(212, 116);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(100, 22);
            this.txtSDT.TabIndex = 45;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(212, 209);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(100, 22);
            this.txtDiaChi.TabIndex = 44;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(212, 73);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 22);
            this.txtName.TabIndex = 43;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(79, 262);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 16);
            this.label5.TabIndex = 42;
            this.label5.Text = "Ghi chú";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(79, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 16);
            this.label4.TabIndex = 41;
            this.label4.Text = "Số điện thoại";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(79, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 16);
            this.label3.TabIndex = 40;
            this.label3.Text = "Cơ quan";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(79, 209);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 16);
            this.label2.TabIndex = 39;
            this.label2.Text = "Địa chỉ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(79, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 16);
            this.label1.TabIndex = 38;
            this.label1.Text = "Họ và tên";
            // 
            // suaNguoiDung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnThemTP);
            this.Controls.Add(this.txtTP);
            this.Controls.Add(this.txtQH);
            this.Controls.Add(this.txtCQ);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.btnThemQH);
            this.Controls.Add(this.btnThemCQ);
            this.Controls.Add(this.txtGhiChu);
            this.Controls.Add(this.txtSDT);
            this.Controls.Add(this.txtDiaChi);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "suaNguoiDung";
            this.Text = "suaNguoiDung";
            this.Load += new System.EventHandler(this.suaNguoiDung_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnThemTP;
        private System.Windows.Forms.TextBox txtTP;
        private System.Windows.Forms.TextBox txtQH;
        private System.Windows.Forms.TextBox txtCQ;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnThemQH;
        private System.Windows.Forms.Button btnThemCQ;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}