﻿using System;

namespace QuanLyDanhBa
{
    partial class themDiachi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIdQH = new System.Windows.Forms.TextBox();
            this.txtTenQH = new System.Windows.Forms.TextBox();
            this.btnThemAddress = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(67, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID Quận Huyện";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(67, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên Quận Huyện";
            // 
            // txtIdQH
            // 
            this.txtIdQH.Location = new System.Drawing.Point(212, 68);
            this.txtIdQH.Name = "txtIdQH";
            this.txtIdQH.Size = new System.Drawing.Size(185, 22);
            this.txtIdQH.TabIndex = 4;
            // 
            // txtTenQH
            // 
            this.txtTenQH.Location = new System.Drawing.Point(212, 113);
            this.txtTenQH.Name = "txtTenQH";
            this.txtTenQH.Size = new System.Drawing.Size(185, 22);
            this.txtTenQH.TabIndex = 5;
            // 
            // btnThemAddress
            // 
            this.btnThemAddress.Location = new System.Drawing.Point(115, 242);
            this.btnThemAddress.Name = "btnThemAddress";
            this.btnThemAddress.Size = new System.Drawing.Size(75, 23);
            this.btnThemAddress.TabIndex = 8;
            this.btnThemAddress.Text = "Thêm";
            this.btnThemAddress.UseVisualStyleBackColor = true;
            this.btnThemAddress.Click += new System.EventHandler(this.btnThemAddress_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.Location = new System.Drawing.Point(260, 242);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(75, 23);
            this.btnHuy.TabIndex = 9;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // themDiachi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 339);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnThemAddress);
            this.Controls.Add(this.txtTenQH);
            this.Controls.Add(this.txtIdQH);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "themDiachi";
            this.Text = "themDiachi";
            this.Load += new System.EventHandler(this.themDiachi_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIdQH;
        private System.Windows.Forms.TextBox txtTenQH;
        private System.Windows.Forms.Button btnThemAddress;
        private System.Windows.Forms.Button btnHuy;
    }
}