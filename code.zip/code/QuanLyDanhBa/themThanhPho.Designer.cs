﻿namespace QuanLyDanhBa
{
    partial class themThanhPho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnThemAddress = new System.Windows.Forms.Button();
            this.txtTenTP = new System.Windows.Forms.TextBox();
            this.txtIdTP = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnHuy
            // 
            this.btnHuy.Location = new System.Drawing.Point(436, 274);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(75, 23);
            this.btnHuy.TabIndex = 15;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.UseVisualStyleBackColor = true;
            // 
            // btnThemAddress
            // 
            this.btnThemAddress.Location = new System.Drawing.Point(323, 274);
            this.btnThemAddress.Name = "btnThemAddress";
            this.btnThemAddress.Size = new System.Drawing.Size(75, 23);
            this.btnThemAddress.TabIndex = 14;
            this.btnThemAddress.Text = "Thêm";
            this.btnThemAddress.UseVisualStyleBackColor = true;
            this.btnThemAddress.Click += new System.EventHandler(this.btnThemAddress_Click);
            // 
            // txtTenTP
            // 
            this.txtTenTP.Location = new System.Drawing.Point(380, 211);
            this.txtTenTP.Name = "txtTenTP";
            this.txtTenTP.Size = new System.Drawing.Size(185, 22);
            this.txtTenTP.TabIndex = 13;
            // 
            // txtIdTP
            // 
            this.txtIdTP.Location = new System.Drawing.Point(380, 154);
            this.txtIdTP.Name = "txtIdTP";
            this.txtIdTP.Size = new System.Drawing.Size(185, 22);
            this.txtIdTP.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(235, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "Tên Thành Phố";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(235, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 10;
            this.label3.Text = "ID Thành Phố";
            // 
            // themThanhPho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnThemAddress);
            this.Controls.Add(this.txtTenTP);
            this.Controls.Add(this.txtIdTP);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Name = "themThanhPho";
            this.Text = "themThanhPho";
            this.Load += new System.EventHandler(this.themThanhPho_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnThemAddress;
        private System.Windows.Forms.TextBox txtTenTP;
        private System.Windows.Forms.TextBox txtIdTP;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}