﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyDanhBa
{
    public partial class themCoQuan : Form
    {
        private string connectionString = @"Data Source=VUHOANG\SQLEXPRESS;Initial Catalog=quanLyDanhBa;Integrated Security=True;Encrypt=False;"; // Chuỗi kết nối đến cơ sở dữ liệu

        public themCoQuan()
        {
            InitializeComponent();
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            // Đóng form hiện tại
            this.Close();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ các ô nhập liệu
            string idCoQuan = txtIdCQ.Text.Trim();
            string tenCoQuan = txtTenCQ.Text.Trim();

            // Kiểm tra dữ liệu nhập liệu
            if (string.IsNullOrEmpty(tenCoQuan))
            {
                MessageBox.Show("Vui lòng nhập tên cơ quan!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Kết nối đến cơ sở dữ liệu
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Kiểm tra xem cơ quan đã tồn tại hay chưa
                    string checkQuery = "SELECT COUNT(*) FROM tblCoQuan WHERE idCoQuan = @idCoQuan";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@idCoQuan", idCoQuan);
                        int count = (int)checkCommand.ExecuteScalar();

                        if (count > 0)
                        {
                            MessageBox.Show("Cơ quan đã tồn tại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // Thêm cơ quan mới nếu chưa tồn tại
                    string insertQuery = "INSERT INTO tblCoQuan (idCoQuan, tenCoQuan) VALUES (@idCoQuan, @tenCoQuan)";
                    using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@idCoQuan", idCoQuan);
                        insertCommand.Parameters.AddWithValue("@tenCoQuan", tenCoQuan);
                        insertCommand.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Thêm cơ quan thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Đóng form hiện tại sau khi thêm thành công
                this.Close();
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show("Lỗi SQL khi thêm cơ quan: " + sqlEx.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm cơ quan: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void themCoQuan_Load(object sender, EventArgs e)
        {

        }
    }
}
